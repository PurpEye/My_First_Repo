## ics-ibids
### Todo List-
1. Continuous Monitoring  
2. Cleanup-code and make more efficient especially txt2csv (removal)  
3. Make data_test uniquely writeable  
4. Dockerize  
5. Addition of resptime (Layer 3? to features)

