#/bin/sh
rm txt/capture_111*
rm csv/capture_111*
#rm pcap/capture_111*
rm data_test
rm label_test

