#/bin/sh
rm csv/*.csv
rm txt/*.txt
rm label_test
rm label_train
rm data_train
rm data_test
